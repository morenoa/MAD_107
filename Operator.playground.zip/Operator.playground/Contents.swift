//: Playground - noun: a place where people can play

import Cocoa

//Sec 01//

var num1 = 2, num2 = 5, num3 = 39, num4 = 38, num5 = 104

var f1 = 2.5, f2 = 0.3, f3 = 132.5, f4 = 230.47, f5 = 6.6


//Sec 02//

var r1:Double = Double(num1) * f1

var tail7: Bool = Int(r1) == (num2)

var r2 = num4 % num1

var tail6: Bool = Int(r1) == r2

var r3 = num3 - num1

var tail5: Bool = r3 != num4

var tail4: Bool = f4 < Double(num5)

var tail1: Bool = r1 <= Double(num2) || r2 == num3

var tail2: Bool = r1 <= Double(num2) && r2 == num3

var tail3: Bool = f2 < r1

var f6 = (num3 * num1) - num5

var f7 = (f3 + f1 - (f5 * f2)) / f4

//Sec 03//

print(r1, "\n", r2,"\n", r3,"\n", tail1,"\n", tail2,"\n", tail3,"\n", tail4,"\n", tail5,"\n", tail6,"\n", f6,"\n", f7)