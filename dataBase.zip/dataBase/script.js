$(document).ready(function () {
	"use strict";
    $("#button").click(function () {
        var toAdd = $("input[name=checkListForm]").val();
        $("#list").append('<div class="item">' + toAdd +'</div>');
    });
	
	$("#button").bind("click", function() {
		$("input[type=text], textarea").val("");
	});

    $(document).on("click",".item",function () {
        $(this).remove();

    });
    
});