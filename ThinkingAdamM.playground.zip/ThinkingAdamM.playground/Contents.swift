//: Playground - noun: a place where people can play

import Cocoa

let one = 1;
let pi: Double = 3.14159265359;

var result: Float;
var length: Int;

print("Lets draw a circle with a radius of ", one, ".");
print("The distance half way around the circle is ", pi, " a number known as Pi");
print("Lets do a experiment!");
print("You walk around a circle which has a diameter of 100m, how far have you walked?");
length = 100;
result = Float(pi * Double(length));
print("Distance walked = Circumference = ", result);