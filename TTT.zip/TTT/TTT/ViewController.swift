//
//  ViewController.swift
//  TTT
//
//  Created by Adam Moreno on 9/18/17.
//  Copyright © 2017 Adam Moreno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var player = 1
    var game = [0,0,0,0,0,0,0,0,0]

    @IBAction func ationButton(_ sender: AnyObject) {
        if (game[sender.tag-1] == 0)
        {
            game[sender.tag-1] = player
            
            if (player == 1) {
                sender.setImage(UIImage(named: "cross.png"), for: UIControlState())
                player = 2
            }
            else
            {
                sender.setImage(UIImage(named: "Nought.png"), for: UIControlState())
                player = 1
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

