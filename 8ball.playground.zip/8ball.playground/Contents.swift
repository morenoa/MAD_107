//: Playground - noun: a place where people can play

import Cocoa

let commonTerms: [Int: String] = [
    1: "standing", 2: "championship", 3: "night", 4: "tomorrow", 5: "against", 6: "next", 7: "vs"
]

var space: String = " "

func Animal(topic: String) -> Bool
{
    let animal: [String] = ["giraffe", "brahma chicken", "chicken", "dog", "snake"]
    var num: Int = 0
    
    while num < animal.count
    {
        if animal[num] == topic
        {
            return true
        }
        num += 1
    }
    return false}

func Actor(topic: String) -> Bool
{
    let actors: [String] = ["paige", "emma watson", "charo", "dave chappelle", "rober osborn"]
    var state: Bool = false
    
    for actors in actors
    {
        if actors == topic
        {
            state = true
        }
        else
        {
            state = false
        }
    }
    return state
}

func Chicken(stringarray: String)
{
    var array1 = stringarray.components(separatedBy: " ")
    if ((array1[0] + space + array1[1]) == "how long") || ((array1[0] + space + array1[1] + space + array1[2]) == "how to cook")
    {
        print("Well, I would say to go to a cookbook for that, because I cannot tell you my secret cooking ways.")
    }
    
}

func Teams(topic: String) -> Bool
{
    let sport: [String] = ["mets", "sox", "gaints", "Yankees", "blackhawks"]
    var num: Int = 0
    
    while num < sport.count
    {
        if sport[num] == topic
        {
            return true
        }
        num += 1
    }
    return false
}

func redSox(stringarray: String)
{
    var array2 = stringarray.components(separatedBy: " ")
    let topTerms = [String](commonTerms.values)
    var i: Int = 0
    var a: Int = 0
    var b: Bool = true
    while i < topTerms.count
    {
        while <#condition#> {
            <#code#>
        }
    }
}

var statment: String = "will the sox win tomorrow"
var array = statment.components(separatedBy: " ")

var arrayCount: Int = 0
var trend: String = " "

while arrayCount < array.count
{
    trend = array[arrayCount]
    
    if Animal(topic: trend) == true
    {
        print("this is an animal topic")
        Chicken(stringarray: statment)
        
    }
    else if Actor(topic: trend) == true
    {
        print("this is an actor topic")
    }
    else if Teams(topic: trend) == true
    {
        print("this is an team topic")
        redSox(stringarray: statment)
    }
    
    arrayCount += 1
    
}

