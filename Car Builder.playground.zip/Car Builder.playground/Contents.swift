//: Playground - noun: a place where people can play

import Cocoa

class Car
{
    var Model: String = "model"
    var Year: Int = 0
    var Color: String = "color"
    var Transmition: String = "gear"
    var price: Int = 0
    
    func model(Model: String)
    {
        if Model == "Prius"
        {
            price += 24000
        }
        else if Model == "Prius C"
        {
            price += 26000
        }
        else if Model == "Prius V"
        {
            price  += 28000
        }
    }
    
    func year(Year: Int)
    {
        if Year == 2017
        {
            price += 2000
        }
        else if Year <= 2016
        {
            price += 1000
        }
    }
    
    func trans(Transmition: String)
    {
        if Transmition == "Mannuel"
        {
            price += 3000
        }
        else if Transmition == "Automatic"
        {
            price += 1500
        }
    }
    
    func order() -> String
    {
        return ("You have ordered a \(self.Year) \(self.Color) \(self.Transmition) \(self.Model) With a price of \(self.price).")
    }
}

var c = Car()

c.Color = "Red"
c.Model = "Prius"
c.Year = 2017
c.Transmition = "Automatic"

c.model(Model: "Prius")
c.trans(Transmition: "Automatic")
c.year(Year: 2017)

print(c.order())
