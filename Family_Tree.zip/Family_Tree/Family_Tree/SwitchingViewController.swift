//
//  SwitchingViewController.swift
//  Family_Tree
//
//  Created by Adam Moreno on 10/1/17.
//  Copyright © 2017 Adam Moreno. All rights reserved.
//

import UIKit

class SwitchingViewController: UIViewController {

    private var yourViewController: YourViewController!
    private var momsViewController: MomsViewController!
    private var dadsViewController: DadsViewController!
    
    @IBOutlet weak var BarButton: UIBarButtonItem!
    
    private func switchViewController(from fromVC:UIViewController?, to toVC:UIViewController?){
        if fromVC != nil {
            fromVC!.willMove(toParentViewController: nil)
            fromVC!.view.removeFromSuperview()
            fromVC!.removeFromParentViewController()
        }
        if toVC != nil {
            self.addChildViewController(toVC!)
            self.view.insertSubview(toVC!.view, at: 0)
            toVC!.didMove(toParentViewController: self)
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        yourViewController = storyboard?.instantiateViewController(withIdentifier: "Your")
            as! YourViewController
        yourViewController.view.frame = view.frame
        switchViewController(from: nil, to: yourViewController) //helper method to be written a little later
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        if yourViewController != nil && yourViewController!.view.superview == nil {
            yourViewController = nil
        }
        if momsViewController != nil && momsViewController!.view.superview == nil {
            momsViewController = nil
        }
        if dadsViewController != nil && dadsViewController!.view.superview == nil {
            dadsViewController = nil
        }
    }
    
    
    @IBAction func switchViews(sender: UIBarButtonItem){
        //Create new views if needed
        if momsViewController?.view.superview == nil {
            if momsViewController == nil {
                momsViewController = storyboard?.instantiateViewController(withIdentifier: "Moms")
                    as! MomsViewController
            }
        } else if dadsViewController?.view.superview == nil {
            if dadsViewController == nil {
                dadsViewController = storyboard?.instantiateViewController(withIdentifier: "Dads")
                    as! DadsViewController
            }
        } else if yourViewController?.view.superview == nil {
            if yourViewController == nil {
                yourViewController = storyboard?.instantiateViewController(withIdentifier: "Your")
                    as! YourViewController
            }
        }
        UIView.beginAnimations("View Flip", context: nil)
        UIView.setAnimationDuration(0.4)
        UIView.setAnimationCurve(.easeInOut)
        
        //switch view controllers
        if yourViewController != nil && yourViewController!.view.superview != nil{
            UIView.setAnimationTransition(.flipFromRight, for: view, cache: true)
            momsViewController.view.frame=view.frame
            switchViewController(from: yourViewController, to: momsViewController)}
        else if momsViewController != nil && momsViewController!.view.superview != nil{
            UIView.setAnimationTransition(.flipFromRight, for: view, cache: true)
            dadsViewController.view.frame = view.frame
            switchViewController(from: momsViewController, to: dadsViewController)
            
        } else if dadsViewController != nil && dadsViewController!.view.superview != nil{
            UIView.setAnimationTransition(.flipFromLeft, for: view, cache: true)
            yourViewController.view.frame = view.frame
            switchViewController(from: dadsViewController, to: yourViewController)
            
        }
        
        UIView.commitAnimations()
        
        
        
        
        //Switch view controllers
        /*if yourViewController != nil && yourViewController!.view.superview != nil {
         momsViewController.view.frame = view.frame
         switchViewController(from: yourViewController, to: momsViewController)
         } else if momsViewController.view.frame == view.frame{
         dadsViewController.view.frame = view.frame
         switchViewController(from: momsViewController, to: dadsViewController)
         } else if dadsViewController.view.frame == view.frame{
         yourViewController.view.frame = view.frame
         switchViewController(from: dadsViewController, to: yourViewController)
         }*/
        
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */

}
