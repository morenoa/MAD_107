//: Playground - noun: a place where people can play

import Cocoa

var num1 = 3;
var num2 = 3.14159265359;
var num3 = 3.14159265359;

print(3.14159265359);
print("printing int ", num1, ", printing float ", num2, " printing double ", num3);

let NUM1 = (3);
let NUM2 = 3.14159265359;
let NUM3 = 3.14159265359;

print("printing int ", NUM1, ", printing float ", NUM2, " printing double ", NUM3);

var num4: Int = Int(3.14159265359);
var num5: Float = 3.14159265359;
var num6: Double = 3.14159265359;

print("printing int ", num4, ", printing float ", num5, " printing double ", num6);

let NUM7: Float = 3.14159265359;

//error//
//NUM7 += 4;//

let NUM8 : Float = 4;
// prints out 4.0 instead of 4. //

print(NUM8);
