//: Playground - noun: a place where people can play

import Cocoa

enum BillsWeBurgers:Int
{
    case ZaNasty = 1
    case SoFine
    case AJ_Jacobs
    case TheHipHuger
}

var option: Int?


func Selection(index: Int)
{
    if BillsWeBurgers(rawValue: index) == .ZaNasty
    {
        print ("You have order \(PizzaBurger.a), a true pizza burger. It comes with the following ingredients \(PizzaBurger.b),.")
    }
    else if BillsWeBurgers(rawValue: index) == .SoFine
    {
        print ("You have order \(PizzaBurger.c), They Sexiest burger you'll ever lay your eys on. It comes with the following ingredients \(PizzaBurger.d),.")
    }
    else if BillsWeBurgers(rawValue: index) == .AJ_Jacobs
    {
        print ("You have order \(PizzaBurger.e), consider by Google the healthiest man alive. It comes with the following ingredients \(PizzaBurger.f),.")
    }
    else if BillsWeBurgers(rawValue: index) == .TheHipHuger
    {
        print ("You have order \(PizzaBurger.g), the most simpliest and yet by far the tastiest. It comes with the following ingredients \(PizzaBurger.h),.")
    }
    else
    {
        print("Selection not supported!")
    }
}

struct Nasty
{
    var a: String = "The Nasty"
    var b: String = "pound of Ground Beef, pound Italian of Sausage, Provolone Cheese, Pepperoni Slices, Marinara Sauce, Parmesan Cheese"
    var c: String = "The So Fine"
    var d: String = "avocados, mayonnaise, Heinz chili sauce, Sriracha chili sauce, 2 pounds of fresh ground, chuck, ounces of cooked lobster meat, fine chopped onion"
    var e: String = "The AJ Jacobs"
    var f: String = "red lentils, rinsed and drained, chickpeas, rinsed and drained, cilantro, jalapeno, red onion, red bell pepper, carrot, oat bran, mango, avocado"
    var g: String = "The Hip Huger"
    var h: String = "2 pounds of ground beef and lamb, onions, Tahini and salsa sauce"
}

var PizzaBurger = Nasty()

option = 22
Selection(index: option!)

