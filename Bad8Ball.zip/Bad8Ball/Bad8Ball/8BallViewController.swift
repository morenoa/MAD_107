//
//  8BallViewController.swift
//  Bad8Ball
//
//  Created by Adam Moreno on 10/10/17.
//  Copyright © 2017 Adam Moreno. All rights reserved.
//

import UIKit

class _BallViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var insultPicker: UIPickerView!
    
    private let insultOne = 0
    private let insultTwo = 1
    private let insultOneTypes = ["cat", "dog", "cow", "idoit", "slow", "old", "fat"]
    private let insultTwoTypes = ["big butt", "sissy hands", "wet oily mouth"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onButtonPressed(_ sender: UIButton) {
        let insultOneRow = insultPicker.selectedRow(inComponent: insultOne)
        let insultTwoRow = insultPicker.selectedRow(inComponent: insultTwo)
        let oneInsult = insultOneTypes[insultOneRow]
        let twoInsult = insultTwoTypes[insultTwoRow]

        
        let message = "It's better to let someone think you are a \(oneInsult), than to open your \(twoInsult)"
        
        let alert = UIAlertController(
            title: "Hello",
            message: message,
            preferredStyle: .alert)
        
        let action = UIAlertAction(
            title: "Goobye",
            style: .default,
            handler: nil)
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == insultTwo{
            return insultTwoTypes.count} else {
            return insultOneTypes.count}
    }
    
    //MARK:-
    //MARK: Picker Delegate Methods
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == insultTwo {
            return insultTwoTypes[row]}
        else {
            return insultOneTypes[row]}
    }
    
}
