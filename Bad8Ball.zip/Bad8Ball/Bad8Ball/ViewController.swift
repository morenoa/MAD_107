//
//  ViewController.swift
//  Bad8Ball
//
//  Created by Adam Moreno on 10/10/17.
//  Copyright © 2017 Adam Moreno. All rights reserved.
//

import UIKit

class ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

