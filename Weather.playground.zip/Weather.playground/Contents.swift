//: Playground - noun: a place where people can play

import Cocoa

var time: Double = 0930
var temp: Int = 50
var motion: String = "Awake"
var pullin: String = "poor"
var weather: String = "rain"
var timeResult: String
var tempResult: String
var pollin: String
var mood: String

while motion == "Awake"
{
    if time >= 0500 && time < 1100
    {
        timeResult = "Godd Morning!"
    }
    else if time >= 1100 && time < 1500
    {
        timeResult = " Good Afternoon!"
    }
    else if time >= 1500 && time < 1900
    {
        timeResult = "Good Evening!"
    }
    else
    {
        timeResult = "Have a good night!"
    }
    
    if temp < 30
    {
        tempResult = "It's freezing! Bundle up."
    }
    else if temp > 30 && temp <= 50
    {
        tempResult = "It's cold! Wear a coat."
    }
    else if temp > 50 && temp <= 75
    {
        tempResult = "It's chilly. Dress warm"
    }
    else
    {
        tempResult = "It's warm. Have fun"
    }
    
    if pullin == "low"
    {
        pollin = "Air quality is good."
    }
    else if pullin == "mild"
    {
        pollin = "Air quality is O.K."
    }
    else{
        pollin = "Air Quality is poor."
    }
    
    if weather == "sunny"
    {
        mood = "Have a great day!"
    }
    else{
        mood = "Take care."
    }
    print(timeResult, tempResult, " and the ", pollin, "",mood)
    motion = "sleep"
}
