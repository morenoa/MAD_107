//
//  ViewController.swift
//  contactList
//
//  Created by Adam Moreno on 10/14/17.
//  Copyright © 2017 Adam Moreno. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    private let contacts = [
        "Adam", "Cody", "Shannon", "Hollis",
        "Emilia", "Shannon2", "Chris Sully",
        "Drew Sully", "Garshie"
    ]
    
    
    
    let simpleTableIdentifier = "SimpleTableIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: simpleTableIdentifier)
        if (cell == nil) {
            cell = UITableViewCell(
                style: UITableViewCellStyle.default,
                reuseIdentifier: simpleTableIdentifier)
        }
        
        
        cell?.textLabel?.text = contacts[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rowValue = contacts[indexPath.row]
        var message:String = " "
        
        switch  indexPath.row{
        case 0:
            message = "+ 1 555 321 2329"
        case 1:
            message = "+ 1 555 947 4389"
        case 2:
            message = "+1 555 123 2948"
        case 3:
            message = "+1 555 294 5793"
        case 4:
            message = "+49 555 101 0088"
        case 5:
            message = "+1 555 888 8888"
        case 6:
            message = "+1 555 123 4924"
        case 7:
            message = "+1 555 120 1942"
        default:
            message = "+1 555 392 2342"
        }
        
        let controller = UIAlertController(title: "Contact Selected",
                                           message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Call \(rowValue)",
                                   style: .default, handler: nil)
        let action2 = UIAlertAction(title: "Text \(rowValue)",
            style: .default, handler: nil)
        
        controller.addAction(action)
        controller.addAction(action2)
        present(controller, animated: true, completion: nil)
    }
    

}

