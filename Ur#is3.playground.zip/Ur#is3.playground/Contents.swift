//: Playground - noun: a place where people can play

import Cocoa

print("Here's a cool math trick");
print("Lets say you a number. Let say that number is 50.");
print("Multiply your number by 2.");
print("Multiply the number by 5.");
print("Divid the number by the original number.");
print("now subtract 7 from it.");
print("Your final answer is 3. It will always be three with any postive"
    + " integer.");
var val: Int = ((((50 * 2) * 5) / 50) - 7)
print(val)